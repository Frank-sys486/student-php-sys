<nav class="nav">
	<ul>
		<li><a href = 'index.php' title = 'Back to Home'> Home </a></li>
		<li><a href = 'shop.php' title = 'About Me'> Shop </a></li>
		<li><a href = 'register-page.php' title = 'Register Here'> Register</a></li>
		<li><a href = 'register-view-users.php' title = 'View All Users'> View Users</a></li>
	</ul>
</nav>