<!doctype HTML>
<html lang=en>
        <head>
            <title>
                Borromeo Web
            </title>
            <meta charset="utf-8" name="viewport">
            <link rel="stylesheet" type="text/css" href="css/style.css">
        </head>

        <body>
        <?php include('nav.php');?>
        
        <div class="registration-form">
            <div class="container">
                <h2 style="color: white;">Thank You for Curiosity!</h2>
                <p style="color: white;">but the page is still progressing...</p>
                <br>
                <a href="index.php" class="order-bttn">Go back to Home</a>
            </div>
        </div>

        </body>
</html>


