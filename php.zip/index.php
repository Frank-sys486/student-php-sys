<!doctype HTML>
<html lang=en>
        <head>
            <title>
                Borromeo Web
            </title>
            <meta charset="utf-8" name="viewport">
            <link rel="stylesheet" type="text/css" href="css/style.css">
        </head>

        <body>
            
                <?php include('nav.php');?>
            
            <div class="s100rr">
                <div class = "s100rr-overlay">
                    <p > BMW S100RR </p>
                    <p class = 'order-bttn'>ORDER</p>
                </div>
            </div>
        </body>
</html>


